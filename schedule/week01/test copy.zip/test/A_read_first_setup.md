# Python and Jupyter Setup Check

I am assuming that you have already installed **Visual Studio Code (VS Code)**.

I also saw from the questionnaire that many of you have already taken Python courses. Even so, please take a few minutes to confirm that you can open and run the attached Jupyter Notebook in VS Code.

## 1. Install Python if Needed

If you do not already have Python installed, download and install the current version of **Python 3** from:

https://www.python.org/downloads/

### Windows

During installation, make sure you select:

**Add python.exe to PATH**

After Python is installed, **close VS Code and open it again**.

### macOS

Install Python 3 normally from the Python website.

After Python is installed, **close VS Code and open it again**.

## 2. Install the VS Code Extensions

In VS Code, click the **Extensions** icon on the left side.

Install these two extensions from **Microsoft**:

- **Python**
- **Jupyter**

These extensions allow VS Code to run Python programs and Jupyter Notebooks.

## 3. Check your installation

### Windows

Open a terminal in VS Code:

**Terminal → New Terminal**

or use the shortcut:

**Control + Shift + `**

Then type:

```bash
python --version
```

If that does not work, try:

```bash
py --version
```

You should see something similar to:

```text
Python 3.x.x
```

### macOS

Open a terminal in VS Code:

**Terminal → New Terminal**

or use the shortcut:

**Control + Shift + `**

Then type:

```bash
python3 --version
```

You should see something similar to:

```text
Python 3.x.x
```

I completely forgot to mention this during class: on a Mac, it is very common for Python 3 to be called **`python3`** rather than **`python`**.

## 4. Test the Jupyter Notebook

Finally, verify that you can open and run a Jupyter Notebook in VS Code.

1. Download the folder attached to this message.
2. Drag the folder into VS Code, or use **File → Open Folder**.
3. Open the `Jupyter_Setup_Test.ipynb` file.
4. Follow the instructions inside the notebook.
5. Click the **▶ Run** button next to the Python cell.

The first time you run the notebook, VS Code may ask you to select a **Python Environment** or **Kernel**. Select the most recent Python 3 version that you installed.

You do **not** need to create a new virtual environment for this exercise.

If you can run the notebook and see the congratulations message, your Python + Jupyter + VS Code setup is ready for class.

## 5. If Python and Jupyter work

Go to the classroom Google Sheet and let me know that you finished the tasks.
https://docs.google.com/spreadsheets/d/1myAX36CDLwGBuvbn_OJLw4ExsRFbwecN61hkxqma4ew/edit?usp=sharing

